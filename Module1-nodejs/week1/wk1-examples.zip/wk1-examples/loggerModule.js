//MODULE EXAMPLE
//The logger is for logging messages to the console.