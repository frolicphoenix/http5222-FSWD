import { getMessage, setMessage } from "./loggerModule.js";

getMessage();
setMessage("This is my new message");
getMessage();