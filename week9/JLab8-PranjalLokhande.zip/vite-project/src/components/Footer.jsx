export default function Footer() {

    return(
        <footer id="footer">
            <div>&copy; Trivia App, 2024.</div>
        </footer>
    );
}