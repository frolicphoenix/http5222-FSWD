export default function Hero (props) {
    return (
        <div className='hero'>
          <div className='hero-header'>
            <h1>Anime Production Houses and Studios</h1>
            <button>Check them out</button>
          </div>
        </div>
    );
}