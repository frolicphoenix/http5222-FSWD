export default function Footer() {

    return(
        <footer id="footer">
            <div>&copy; Beyond Anime, 2024.</div>
        </footer>
    );
}