export default function Header() {

    return(
        <header id="header">
            <h2 id="site-name"><a href="/">Beyond Anime</a></h2>
        </header>
    );
}