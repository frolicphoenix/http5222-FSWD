import { addVeggies, countVeggies, showArray } from "./nscript.js";

addVeggies("broccoli");
addVeggies("spinach");
addVeggies("lettuce");
addVeggies("onion");

console.log(showArray());
console.log(countVeggies());